# Rotary-AndroidApp
Android App for health Appointment System RealTime Token Basis
