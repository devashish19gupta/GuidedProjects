package dev.pardeep.healthappointment;

/**
 * Created by pardeep on 28/12/16.
 */

public class ViewPagerIntroAdapter {
}
